---
name: Aura of Heritage
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#4d4635'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e2'
  on-secondary-container: '#646464'
  tertiary: '#60603e'
  on-tertiary: '#ffffff'
  tertiary-container: '#b6b58c'
  on-tertiary-container: '#474727'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#e6e5b9'
  tertiary-fixed-dim: '#cac99f'
  on-tertiary-fixed: '#1d1d03'
  on-tertiary-fixed-variant: '#484828'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
  quote:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style
The design system is anchored in the concept of "Modern Heritage." It targets high-net-worth individuals seeking an experience that feels both historically significant and contemporary. The aesthetic is a blend of **High-End Minimalism** and **Editorial Luxury**, characterized by expansive whitespace, precision-aligned elements, and a restrained use of ornamentation.

The emotional response should be one of quiet confidence, exclusivity, and absolute trust. By utilizing a "less is more" approach, the product allows the jewelry—the hero of the experience—to breathe, framed by high-contrast tones and meticulous structural details.

## Colors
The palette leverages a high-contrast relationship between deep obsidian tones and metallic luster.

- **Primary (Rich Gold):** Used sparingly for accents, critical calls to action, and fine decorative borders. It represents the value and craftsmanship of the product.
- **Secondary (Deep Black):** The foundation for typography and structural framing. It provides a sense of gravity and permanence.
- **Tertiary (Warm Cream):** Applied as the primary background color to soften the UI, making it feel more like high-quality vellum paper than a digital screen.
- **Neutral (Charcoal):** Used for secondary text and subtle dividers where pure black would be too jarring.

## Typography
The typography strategy pairings high-contrast Serifs with geometric Sans-Serifs to balance tradition with utility.

- **Headlines:** Use **Playfair Display**. Its high stroke contrast and elegant terminals evoke the feeling of luxury fashion mastheads. Use `display-lg` for hero sections with tight letter spacing.
- **Body:** Use **Manrope**. It provides a clean, modern counterpoint to the serif headings, ensuring technical details and product descriptions are highly legible.
- **Labels:** Small caps with generous letter spacing should be used for categories, breadcrumbs, and metadata to reinforce the "boutique" feel.

## Layout & Spacing
This design system employs a **Fixed Grid** philosophy on desktop to maintain an editorial, magazine-like composition. 

- **Grid:** A 12-column grid with wide 24px gutters.
- **Whitespace:** Emphasize "luxury of space" by using large vertical gaps (`section-gap`) between content blocks. Avoid crowding elements; every item should feel intentionally placed.
- **Alignment:** Center-align hero content for a formal presentation. Use asymmetrical layouts for product showcases to create visual interest and mimic high-end catalogs.

## Elevation & Depth
Depth is conveyed through a combination of **Tonal Layers** and **Subtle Shadows**.

- **Surfaces:** Use the Warm Cream (`#FFFDD0`) as the base layer. Interactive cards should sit on a slightly elevated white surface or use a transparent background with a 1px Gold (`#D4AF37`) border.
- **Shadows:** Avoid heavy, dark shadows. Use extremely diffused, low-opacity shadows (e.g., `blur: 40px, opacity: 0.05`) with a slight warm tint to suggest the object is resting softly on the surface.
- **Outlines:** Use "Ghost Borders"—hairline 1px strokes in Gold—to define primary interactive areas without adding visual bulk.

## Shapes
The shape language is strictly **Sharp (0px)**. 

Rectilinear forms convey stability, precision, and architectural strength. All buttons, input fields, image containers, and cards must have 90-degree corners. This sharp geometry contrasts with the organic, flowing lines of the jewelry pieces themselves, making the products appear more delicate and detailed.

## Components
- **Buttons:** Primary buttons are solid Deep Black with Cream text. Secondary buttons are transparent with a 1px Gold border and Black text. All buttons use `label-caps` typography.
- **Cards:** Product cards use a "frameless" approach. The image occupies the top portion, followed by center-aligned typography. On hover, a subtle 1px Gold border appears.
- **Input Fields:** Minimalist design—only a bottom border (1px) in Deep Black. Labels use the `label-caps` style positioned above the line.
- **Chips/Filters:** Use simple text links with a small Gold dot next to the active selection. No background pills.
- **Lists:** Product specifications should be formatted in a two-column list with a hairline divider in a muted cream-gold tint.
- **Additional Components:**
    - **The Signature Divider:** A horizontal line (1px) that tapers off at the ends or features a small gold diamond icon in the center.
    - **The Curator's Badge:** A small, square gold-bordered element used to highlight "Limited Edition" or "Heritage" pieces.